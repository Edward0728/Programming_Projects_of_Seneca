﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data;
using System.Data.OleDb;

namespace FinalProjecrt
{
    public partial class frmNewCustomer : Form
    {
        public frmNewCustomer(string customerID)
        {
            InitializeComponent();
            labelnewcustomer.Text = customerID;
        }

        private void ButtonAddCustomer_Click(object sender, EventArgs e)
        {
            
                OleDbDataAdapter da = new OleDbDataAdapter();
               // int x = Convert.ToInt32(txtQuantity.Text); //take value from textbox on form
                String sqlAdd = "INSERT INTO CustomerInfo (CustomerID,FirstName,LastName,Telephone,CreditCardInfo) " +
                "VALUES ('" + Convert.ToInt32(labelnewcustomer.Text) + "','" + textFirst.Text + "','" + textLast.Text + "','" + textTelephone.Text + "','" + textCredit.Text + "')";
            //('Goran','Svenk','4164915050','1111222233335555'
            //sqlAdd contains the code for inserting value from the form
            //INSERT INTO Orders (PartID, Description, Price) VALUES (?, ?, ?)
            String constr = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=DatabaseProject.accdb";
            //;Extended Properties='Access 12.0';HDR=YES
            //constr tells the program what program we are using (in this case microsoft access)
            OleDbConnection conobj = new OleDbConnection(constr);
                conobj.Open();
                da.InsertCommand = new OleDbCommand(sqlAdd, conobj);
                da.InsertCommand.ExecuteNonQuery();
                //executes the SQL code
                conobj.Close();
            buttonAddCustomer.Enabled = false;
            this.Hide();
            

        }

        private void FrmNewCustomer_Load(object sender, EventArgs e)
        {

        }

        private void ButtonCancelAddC_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
