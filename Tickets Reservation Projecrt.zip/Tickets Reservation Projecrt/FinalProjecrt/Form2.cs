﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data;
using System.Data.OleDb;

namespace FinalProjecrt
{
    public partial class frmPurchase : Form
    {
        
        public static int ticketN;
        public static decimal totalP;
        public static string eventID;
        public static string customerID;
        public static int seatN;
        public static string cardN;


        public frmPurchase(int searchID, decimal searchPrice)
        {
            InitializeComponent();
            labeleventn.Text =  Convert.ToString(searchID);
            labelPriceResult.Text = Convert.ToString(searchPrice);
            labelbeforeavailablen.Text = Convert.ToString(frmSearchEvent.searchAvailable);
            labelbeforesoldn.Text = Convert.ToString(frmSearchEvent.searchSoldN);

        }

        

        private void Form2_Load(object sender, EventArgs e)
        {
            if (labeleventn.Text == "1") { pictureConcert.Visible = true; }
            if (labeleventn.Text == "2") { pictureFilm.Visible = true; }


        }

        private void ButtonCustomerSearch_Click(object sender, EventArgs e)
        {
            DataTable vt = new DataTable();
            
            string sqlSearchC = "SELECT * FROM CustomerInfo WHERE CustomerID =" + Convert.ToInt32(textIDpurchase.Text);
            String constr = " Provider=Microsoft.ACE.OLEDB.12.0;Data Source=DatabaseProject.accdb";
            OleDbDataAdapter da = new OleDbDataAdapter(sqlSearchC, constr);
            if (da != null)
            {
                da.Fill(vt);
                //da.Fill(vt);
                da.Dispose();
                dataGridView1.DataSource = vt;
               
            }
            if (vt.Rows.Count==0)
            {
                frmNewCustomer frm3 = new frmNewCustomer(textIDpurchase.Text);
                frm3.ShowDialog();
            }
        }

        private void DataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            labelFirstName.Text = "First Name: "+(string)dataGridView1[1, 0].Value;
            labelLastName.Text = "Last Name: " + (string)dataGridView1[2, 0].Value;
            labelTelephone.Text = "Telephone #: " + (string)dataGridView1[3, 0].Value;
            labelCredit.Text = "Credit Card #: " + (string)dataGridView1[4, 0].Value;
        }

        private void ButtonSearchAgain_Click(object sender, EventArgs e)
        {
            frmSearchEvent frm0 = new frmSearchEvent();
            frm0.ShowDialog();
            this.Hide();         
        }

        private void ButtonPurchase_Click(object sender, EventArgs e)
        {
            eventID = labeleventn.Text;
            ticketN = Convert.ToInt32(numericUpDownT.Value);
            totalP = Convert.ToDecimal(labelPriceResult.Text) * Convert.ToDecimal(ticketN);
            customerID = textIDpurchase.Text;

            seatN = Convert.ToInt32(numericUpDownSeatN.Value);
            cardN = labelCredit.Text;
            frmReceipt frm4 = new frmReceipt();
            frm4.ShowDialog();
            this.Hide();

        }

        private void ButtonCheckSeat_Click(object sender, EventArgs e)
        {
            DataTable vtSeat = new DataTable();
            string sqlCheck = "SELECT SeatNumber FROM OrderRecords WHERE EventID = " + Convert.ToInt32(labeleventn.Text) +" ORDER BY SeatNumber ASC";
            String constr = " Provider=Microsoft.ACE.OLEDB.12.0;Data Source= DatabaseProject.accdb"; ;
            OleDbDataAdapter da = new OleDbDataAdapter(sqlCheck, constr);
            if (da != null)
            {
                da.Fill(vtSeat);
                //da.Fill(vt);
                da.Dispose();
                dataGridView2.DataSource = vtSeat;
            }
            int j = dataGridView2.RowCount-1;
            string[] seatNsold = vtSeat.Rows.OfType<DataRow>().Select(k => k[0].ToString()).ToArray();                   
            for (int i=0; i<j; i++)
            {
                int seatN = Convert.ToInt32(seatNsold[i]);
                if (seatN == Convert.ToInt32(numericUpDownSeatN.Value))
                {
                    MessageBox.Show("Seat Sold. Please choose another one.");                  
                }
                else { }
            }
            

        }

        private void PictureFilm_Click(object sender, EventArgs e)
        {

        }

        private void PictureConcert_Click(object sender, EventArgs e)
        {

        }
    }
}
