﻿namespace FinalProjecrt
{
    partial class frmPurchase
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmPurchase));
            this.buttonPurchase = new System.Windows.Forms.Button();
            this.buttonSearchAgain = new System.Windows.Forms.Button();
            this.numericUpDownT = new System.Windows.Forms.NumericUpDown();
            this.labelNumber = new System.Windows.Forms.Label();
            this.labelPrice = new System.Windows.Forms.Label();
            this.labelPriceResult = new System.Windows.Forms.Label();
            this.labelCustomerID = new System.Windows.Forms.Label();
            this.textIDpurchase = new System.Windows.Forms.TextBox();
            this.buttonCustomerInfo = new System.Windows.Forms.Button();
            this.labelFirstName = new System.Windows.Forms.Label();
            this.labelLastName = new System.Windows.Forms.Label();
            this.labelTelephone = new System.Windows.Forms.Label();
            this.labelCredit = new System.Windows.Forms.Label();
            this.labelSeat = new System.Windows.Forms.Label();
            this.labelEventID = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.labelSelectC = new System.Windows.Forms.Label();
            this.labelbeforesoldn = new System.Windows.Forms.Label();
            this.labelbeforeSold = new System.Windows.Forms.Label();
            this.labelbeforeavailablen = new System.Windows.Forms.Label();
            this.labelBeforeN = new System.Windows.Forms.Label();
            this.labeleventn = new System.Windows.Forms.Label();
            this.buttonCheckSeat = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.numericUpDownSeatN = new System.Windows.Forms.NumericUpDown();
            this.pictureFilm = new System.Windows.Forms.PictureBox();
            this.pictureConcert = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownT)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownSeatN)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureFilm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureConcert)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonPurchase
            // 
            this.buttonPurchase.Location = new System.Drawing.Point(46, 818);
            this.buttonPurchase.Margin = new System.Windows.Forms.Padding(4);
            this.buttonPurchase.Name = "buttonPurchase";
            this.buttonPurchase.Size = new System.Drawing.Size(211, 44);
            this.buttonPurchase.TabIndex = 0;
            this.buttonPurchase.Text = "Purchase";
            this.buttonPurchase.UseVisualStyleBackColor = true;
            this.buttonPurchase.Click += new System.EventHandler(this.ButtonPurchase_Click);
            // 
            // buttonSearchAgain
            // 
            this.buttonSearchAgain.Location = new System.Drawing.Point(296, 882);
            this.buttonSearchAgain.Margin = new System.Windows.Forms.Padding(4);
            this.buttonSearchAgain.Name = "buttonSearchAgain";
            this.buttonSearchAgain.Size = new System.Drawing.Size(235, 44);
            this.buttonSearchAgain.TabIndex = 1;
            this.buttonSearchAgain.Text = "Search Event";
            this.buttonSearchAgain.UseVisualStyleBackColor = true;
            this.buttonSearchAgain.Click += new System.EventHandler(this.ButtonSearchAgain_Click);
            // 
            // numericUpDownT
            // 
            this.numericUpDownT.Enabled = false;
            this.numericUpDownT.Location = new System.Drawing.Point(185, 686);
            this.numericUpDownT.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDownT.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownT.Name = "numericUpDownT";
            this.numericUpDownT.Size = new System.Drawing.Size(72, 31);
            this.numericUpDownT.TabIndex = 2;
            this.numericUpDownT.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // labelNumber
            // 
            this.labelNumber.AutoSize = true;
            this.labelNumber.Location = new System.Drawing.Point(41, 686);
            this.labelNumber.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelNumber.Name = "labelNumber";
            this.labelNumber.Size = new System.Drawing.Size(98, 25);
            this.labelNumber.TabIndex = 3;
            this.labelNumber.Text = "Quantity:";
            // 
            // labelPrice
            // 
            this.labelPrice.AutoSize = true;
            this.labelPrice.Location = new System.Drawing.Point(41, 591);
            this.labelPrice.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelPrice.Name = "labelPrice";
            this.labelPrice.Size = new System.Drawing.Size(67, 25);
            this.labelPrice.TabIndex = 4;
            this.labelPrice.Text = "Price:";
            // 
            // labelPriceResult
            // 
            this.labelPriceResult.AutoSize = true;
            this.labelPriceResult.Location = new System.Drawing.Point(169, 591);
            this.labelPriceResult.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelPriceResult.Name = "labelPriceResult";
            this.labelPriceResult.Size = new System.Drawing.Size(60, 25);
            this.labelPriceResult.TabIndex = 5;
            this.labelPriceResult.Text = "$$$$";
            // 
            // labelCustomerID
            // 
            this.labelCustomerID.AutoSize = true;
            this.labelCustomerID.Location = new System.Drawing.Point(103, 138);
            this.labelCustomerID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelCustomerID.Name = "labelCustomerID";
            this.labelCustomerID.Size = new System.Drawing.Size(136, 25);
            this.labelCustomerID.TabIndex = 6;
            this.labelCustomerID.Text = "Customer ID:";
            // 
            // textIDpurchase
            // 
            this.textIDpurchase.Location = new System.Drawing.Point(105, 167);
            this.textIDpurchase.Margin = new System.Windows.Forms.Padding(4);
            this.textIDpurchase.Name = "textIDpurchase";
            this.textIDpurchase.Size = new System.Drawing.Size(220, 31);
            this.textIDpurchase.TabIndex = 7;
            // 
            // buttonCustomerInfo
            // 
            this.buttonCustomerInfo.Location = new System.Drawing.Point(103, 213);
            this.buttonCustomerInfo.Margin = new System.Windows.Forms.Padding(4);
            this.buttonCustomerInfo.Name = "buttonCustomerInfo";
            this.buttonCustomerInfo.Size = new System.Drawing.Size(222, 37);
            this.buttonCustomerInfo.TabIndex = 8;
            this.buttonCustomerInfo.Text = "Customer Search";
            this.buttonCustomerInfo.UseVisualStyleBackColor = true;
            this.buttonCustomerInfo.Click += new System.EventHandler(this.ButtonCustomerSearch_Click);
            // 
            // labelFirstName
            // 
            this.labelFirstName.AutoSize = true;
            this.labelFirstName.Location = new System.Drawing.Point(449, 84);
            this.labelFirstName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelFirstName.Name = "labelFirstName";
            this.labelFirstName.Size = new System.Drawing.Size(116, 25);
            this.labelFirstName.TabIndex = 9;
            this.labelFirstName.Text = "First Name";
            // 
            // labelLastName
            // 
            this.labelLastName.AutoSize = true;
            this.labelLastName.Location = new System.Drawing.Point(449, 126);
            this.labelLastName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelLastName.Name = "labelLastName";
            this.labelLastName.Size = new System.Drawing.Size(115, 25);
            this.labelLastName.TabIndex = 10;
            this.labelLastName.Text = "Last Name";
            // 
            // labelTelephone
            // 
            this.labelTelephone.AutoSize = true;
            this.labelTelephone.Location = new System.Drawing.Point(449, 174);
            this.labelTelephone.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelTelephone.Name = "labelTelephone";
            this.labelTelephone.Size = new System.Drawing.Size(132, 25);
            this.labelTelephone.TabIndex = 11;
            this.labelTelephone.Text = "Telephone #";
            // 
            // labelCredit
            // 
            this.labelCredit.AutoSize = true;
            this.labelCredit.Location = new System.Drawing.Point(449, 223);
            this.labelCredit.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelCredit.Name = "labelCredit";
            this.labelCredit.Size = new System.Drawing.Size(139, 25);
            this.labelCredit.TabIndex = 12;
            this.labelCredit.Text = "Credit Card #";
            // 
            // labelSeat
            // 
            this.labelSeat.AutoSize = true;
            this.labelSeat.Location = new System.Drawing.Point(50, 726);
            this.labelSeat.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelSeat.Name = "labelSeat";
            this.labelSeat.Size = new System.Drawing.Size(137, 25);
            this.labelSeat.TabIndex = 13;
            this.labelSeat.Text = "Seat Number";
            // 
            // labelEventID
            // 
            this.labelEventID.AutoSize = true;
            this.labelEventID.Location = new System.Drawing.Point(103, 73);
            this.labelEventID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelEventID.Name = "labelEventID";
            this.labelEventID.Size = new System.Drawing.Size(99, 25);
            this.labelEventID.TabIndex = 15;
            this.labelEventID.Text = "Event ID:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(55, 310);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 82;
            this.dataGridView1.RowTemplate.Height = 33;
            this.dataGridView1.Size = new System.Drawing.Size(830, 187);
            this.dataGridView1.TabIndex = 16;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DataGridView1_CellClick);
            // 
            // labelSelectC
            // 
            this.labelSelectC.AutoSize = true;
            this.labelSelectC.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSelectC.Location = new System.Drawing.Point(41, 538);
            this.labelSelectC.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelSelectC.Name = "labelSelectC";
            this.labelSelectC.Size = new System.Drawing.Size(280, 25);
            this.labelSelectC.TabIndex = 17;
            this.labelSelectC.Text = "(Please Select Customer)";
            // 
            // labelbeforesoldn
            // 
            this.labelbeforesoldn.AutoSize = true;
            this.labelbeforesoldn.Location = new System.Drawing.Point(401, 633);
            this.labelbeforesoldn.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.labelbeforesoldn.Name = "labelbeforesoldn";
            this.labelbeforesoldn.Size = new System.Drawing.Size(36, 25);
            this.labelbeforesoldn.TabIndex = 27;
            this.labelbeforesoldn.Text = "##";
            // 
            // labelbeforeSold
            // 
            this.labelbeforeSold.AutoSize = true;
            this.labelbeforeSold.Location = new System.Drawing.Point(277, 633);
            this.labelbeforeSold.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.labelbeforeSold.Name = "labelbeforeSold";
            this.labelbeforeSold.Size = new System.Drawing.Size(111, 25);
            this.labelbeforeSold.TabIndex = 26;
            this.labelbeforeSold.Text = "Seat Sold:";
            // 
            // labelbeforeavailablen
            // 
            this.labelbeforeavailablen.AutoSize = true;
            this.labelbeforeavailablen.Location = new System.Drawing.Point(225, 633);
            this.labelbeforeavailablen.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.labelbeforeavailablen.Name = "labelbeforeavailablen";
            this.labelbeforeavailablen.Size = new System.Drawing.Size(36, 25);
            this.labelbeforeavailablen.TabIndex = 25;
            this.labelbeforeavailablen.Text = "##";
            // 
            // labelBeforeN
            // 
            this.labelBeforeN.AutoSize = true;
            this.labelBeforeN.Location = new System.Drawing.Point(41, 633);
            this.labelBeforeN.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.labelBeforeN.Name = "labelBeforeN";
            this.labelBeforeN.Size = new System.Drawing.Size(170, 25);
            this.labelBeforeN.TabIndex = 24;
            this.labelBeforeN.Text = "* Seat Available:";
            // 
            // labeleventn
            // 
            this.labeleventn.AutoSize = true;
            this.labeleventn.Location = new System.Drawing.Point(239, 73);
            this.labeleventn.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.labeleventn.Name = "labeleventn";
            this.labeleventn.Size = new System.Drawing.Size(36, 25);
            this.labeleventn.TabIndex = 28;
            this.labeleventn.Text = "##";
            // 
            // buttonCheckSeat
            // 
            this.buttonCheckSeat.Location = new System.Drawing.Point(296, 757);
            this.buttonCheckSeat.Margin = new System.Windows.Forms.Padding(6);
            this.buttonCheckSeat.Name = "buttonCheckSeat";
            this.buttonCheckSeat.Size = new System.Drawing.Size(236, 44);
            this.buttonCheckSeat.TabIndex = 29;
            this.buttonCheckSeat.Text = "Check Seat Available";
            this.buttonCheckSeat.UseVisualStyleBackColor = true;
            this.buttonCheckSeat.Click += new System.EventHandler(this.ButtonCheckSeat_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(544, 538);
            this.dataGridView2.Margin = new System.Windows.Forms.Padding(6);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 82;
            this.dataGridView2.Size = new System.Drawing.Size(332, 388);
            this.dataGridView2.TabIndex = 30;
            // 
            // numericUpDownSeatN
            // 
            this.numericUpDownSeatN.Location = new System.Drawing.Point(46, 757);
            this.numericUpDownSeatN.Margin = new System.Windows.Forms.Padding(6);
            this.numericUpDownSeatN.Name = "numericUpDownSeatN";
            this.numericUpDownSeatN.Size = new System.Drawing.Size(212, 31);
            this.numericUpDownSeatN.TabIndex = 31;
            // 
            // pictureFilm
            // 
            this.pictureFilm.Image = global::FinalProjecrt.Properties.Resources.video_icon_clipart_animated_movie_95860_9687950;
            this.pictureFilm.InitialImage = global::FinalProjecrt.Properties.Resources.video_icon_clipart_animated_movie_95860_9687950;
            this.pictureFilm.Location = new System.Drawing.Point(913, 198);
            this.pictureFilm.Name = "pictureFilm";
            this.pictureFilm.Size = new System.Drawing.Size(512, 512);
            this.pictureFilm.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureFilm.TabIndex = 33;
            this.pictureFilm.TabStop = false;
            this.pictureFilm.Visible = false;
            this.pictureFilm.Click += new System.EventHandler(this.PictureFilm_Click);
            // 
            // pictureConcert
            // 
            this.pictureConcert.Image = ((System.Drawing.Image)(resources.GetObject("pictureConcert.Image")));
            this.pictureConcert.InitialImage = global::FinalProjecrt.Properties.Resources.Concerts_event_icon;
            this.pictureConcert.Location = new System.Drawing.Point(913, 310);
            this.pictureConcert.Name = "pictureConcert";
            this.pictureConcert.Size = new System.Drawing.Size(600, 400);
            this.pictureConcert.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureConcert.TabIndex = 32;
            this.pictureConcert.TabStop = false;
            this.pictureConcert.Visible = false;
            this.pictureConcert.Click += new System.EventHandler(this.PictureConcert_Click);
            // 
            // frmPurchase
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1918, 1062);
            this.Controls.Add(this.pictureFilm);
            this.Controls.Add(this.pictureConcert);
            this.Controls.Add(this.numericUpDownSeatN);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.buttonCheckSeat);
            this.Controls.Add(this.labeleventn);
            this.Controls.Add(this.labelbeforesoldn);
            this.Controls.Add(this.labelbeforeSold);
            this.Controls.Add(this.labelbeforeavailablen);
            this.Controls.Add(this.labelBeforeN);
            this.Controls.Add(this.labelSelectC);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.labelEventID);
            this.Controls.Add(this.labelSeat);
            this.Controls.Add(this.labelCredit);
            this.Controls.Add(this.labelTelephone);
            this.Controls.Add(this.labelLastName);
            this.Controls.Add(this.labelFirstName);
            this.Controls.Add(this.buttonCustomerInfo);
            this.Controls.Add(this.textIDpurchase);
            this.Controls.Add(this.labelCustomerID);
            this.Controls.Add(this.labelPriceResult);
            this.Controls.Add(this.labelPrice);
            this.Controls.Add(this.labelNumber);
            this.Controls.Add(this.numericUpDownT);
            this.Controls.Add(this.buttonSearchAgain);
            this.Controls.Add(this.buttonPurchase);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmPurchase";
            this.Text = "Purchase";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownT)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownSeatN)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureFilm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureConcert)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonPurchase;
        private System.Windows.Forms.Button buttonSearchAgain;
        private System.Windows.Forms.NumericUpDown numericUpDownT;
        private System.Windows.Forms.Label labelNumber;
        private System.Windows.Forms.Label labelPrice;
        private System.Windows.Forms.Label labelPriceResult;
        private System.Windows.Forms.Label labelCustomerID;
        private System.Windows.Forms.Button buttonCustomerInfo;
        private System.Windows.Forms.Label labelFirstName;
        private System.Windows.Forms.Label labelLastName;
        private System.Windows.Forms.Label labelTelephone;
        private System.Windows.Forms.Label labelCredit;
        private System.Windows.Forms.Label labelSeat;
        private System.Windows.Forms.Label labelEventID;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label labelSelectC;
        private System.Windows.Forms.Label labelbeforesoldn;
        private System.Windows.Forms.Label labelbeforeSold;
        private System.Windows.Forms.Label labelbeforeavailablen;
        private System.Windows.Forms.Label labelBeforeN;
        public System.Windows.Forms.TextBox textIDpurchase;
        private System.Windows.Forms.Label labeleventn;
        private System.Windows.Forms.Button buttonCheckSeat;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.NumericUpDown numericUpDownSeatN;
        private System.Windows.Forms.PictureBox pictureConcert;
        private System.Windows.Forms.PictureBox pictureFilm;
    }
}