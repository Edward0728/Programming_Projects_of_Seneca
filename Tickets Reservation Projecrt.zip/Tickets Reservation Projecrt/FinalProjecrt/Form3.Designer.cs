﻿namespace FinalProjecrt
{
    partial class frmNewCustomer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelID = new System.Windows.Forms.Label();
            this.labelFirst = new System.Windows.Forms.Label();
            this.labelLast = new System.Windows.Forms.Label();
            this.labelTelephone = new System.Windows.Forms.Label();
            this.labelCredit = new System.Windows.Forms.Label();
            this.textLast = new System.Windows.Forms.TextBox();
            this.textFirst = new System.Windows.Forms.TextBox();
            this.textTelephone = new System.Windows.Forms.TextBox();
            this.textCredit = new System.Windows.Forms.TextBox();
            this.buttonAddCustomer = new System.Windows.Forms.Button();
            this.labelnewcustomer = new System.Windows.Forms.Label();
            this.buttonCancelAddC = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // labelID
            // 
            this.labelID.AutoSize = true;
            this.labelID.Location = new System.Drawing.Point(73, 40);
            this.labelID.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelID.Name = "labelID";
            this.labelID.Size = new System.Drawing.Size(71, 13);
            this.labelID.TabIndex = 0;
            this.labelID.Text = "Customer ID: ";
            // 
            // labelFirst
            // 
            this.labelFirst.AutoSize = true;
            this.labelFirst.Location = new System.Drawing.Point(73, 69);
            this.labelFirst.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelFirst.Name = "labelFirst";
            this.labelFirst.Size = new System.Drawing.Size(63, 13);
            this.labelFirst.TabIndex = 1;
            this.labelFirst.Text = "First Name: ";
            // 
            // labelLast
            // 
            this.labelLast.AutoSize = true;
            this.labelLast.Location = new System.Drawing.Point(73, 100);
            this.labelLast.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelLast.Name = "labelLast";
            this.labelLast.Size = new System.Drawing.Size(61, 13);
            this.labelLast.TabIndex = 2;
            this.labelLast.Text = "Last Name:";
            // 
            // labelTelephone
            // 
            this.labelTelephone.AutoSize = true;
            this.labelTelephone.Location = new System.Drawing.Point(73, 135);
            this.labelTelephone.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelTelephone.Name = "labelTelephone";
            this.labelTelephone.Size = new System.Drawing.Size(71, 13);
            this.labelTelephone.TabIndex = 3;
            this.labelTelephone.Text = "Telephone #:";
            // 
            // labelCredit
            // 
            this.labelCredit.AutoSize = true;
            this.labelCredit.Location = new System.Drawing.Point(73, 168);
            this.labelCredit.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelCredit.Name = "labelCredit";
            this.labelCredit.Size = new System.Drawing.Size(72, 13);
            this.labelCredit.TabIndex = 4;
            this.labelCredit.Text = "Credit Card #:";
            // 
            // textLast
            // 
            this.textLast.Location = new System.Drawing.Point(155, 100);
            this.textLast.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textLast.Name = "textLast";
            this.textLast.Size = new System.Drawing.Size(82, 20);
            this.textLast.TabIndex = 6;
            // 
            // textFirst
            // 
            this.textFirst.Location = new System.Drawing.Point(155, 68);
            this.textFirst.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textFirst.Name = "textFirst";
            this.textFirst.Size = new System.Drawing.Size(82, 20);
            this.textFirst.TabIndex = 7;
            // 
            // textTelephone
            // 
            this.textTelephone.Location = new System.Drawing.Point(155, 132);
            this.textTelephone.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textTelephone.Name = "textTelephone";
            this.textTelephone.Size = new System.Drawing.Size(82, 20);
            this.textTelephone.TabIndex = 8;
            // 
            // textCredit
            // 
            this.textCredit.Location = new System.Drawing.Point(155, 168);
            this.textCredit.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textCredit.Name = "textCredit";
            this.textCredit.Size = new System.Drawing.Size(164, 20);
            this.textCredit.TabIndex = 9;
            // 
            // buttonAddCustomer
            // 
            this.buttonAddCustomer.Location = new System.Drawing.Point(128, 214);
            this.buttonAddCustomer.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.buttonAddCustomer.Name = "buttonAddCustomer";
            this.buttonAddCustomer.Size = new System.Drawing.Size(106, 23);
            this.buttonAddCustomer.TabIndex = 10;
            this.buttonAddCustomer.Text = "Add Customer";
            this.buttonAddCustomer.UseVisualStyleBackColor = true;
            this.buttonAddCustomer.Click += new System.EventHandler(this.ButtonAddCustomer_Click);
            // 
            // labelnewcustomer
            // 
            this.labelnewcustomer.AutoSize = true;
            this.labelnewcustomer.Location = new System.Drawing.Point(155, 39);
            this.labelnewcustomer.Name = "labelnewcustomer";
            this.labelnewcustomer.Size = new System.Drawing.Size(35, 13);
            this.labelnewcustomer.TabIndex = 11;
            this.labelnewcustomer.Text = "####";
            // 
            // buttonCancelAddC
            // 
            this.buttonCancelAddC.Location = new System.Drawing.Point(244, 34);
            this.buttonCancelAddC.Name = "buttonCancelAddC";
            this.buttonCancelAddC.Size = new System.Drawing.Size(75, 23);
            this.buttonCancelAddC.TabIndex = 12;
            this.buttonCancelAddC.Text = "Cancel";
            this.buttonCancelAddC.UseVisualStyleBackColor = true;
            this.buttonCancelAddC.Click += new System.EventHandler(this.ButtonCancelAddC_Click);
            // 
            // frmNewCustomer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(400, 284);
            this.Controls.Add(this.buttonCancelAddC);
            this.Controls.Add(this.labelnewcustomer);
            this.Controls.Add(this.buttonAddCustomer);
            this.Controls.Add(this.textCredit);
            this.Controls.Add(this.textTelephone);
            this.Controls.Add(this.textFirst);
            this.Controls.Add(this.textLast);
            this.Controls.Add(this.labelCredit);
            this.Controls.Add(this.labelTelephone);
            this.Controls.Add(this.labelLast);
            this.Controls.Add(this.labelFirst);
            this.Controls.Add(this.labelID);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "frmNewCustomer";
            this.Text = "New Customer";
            this.Load += new System.EventHandler(this.FrmNewCustomer_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelID;
        private System.Windows.Forms.Label labelFirst;
        private System.Windows.Forms.Label labelLast;
        private System.Windows.Forms.Label labelTelephone;
        private System.Windows.Forms.Label labelCredit;
        private System.Windows.Forms.TextBox textLast;
        private System.Windows.Forms.TextBox textFirst;
        private System.Windows.Forms.TextBox textTelephone;
        private System.Windows.Forms.TextBox textCredit;
        private System.Windows.Forms.Button buttonAddCustomer;
        private System.Windows.Forms.Label labelnewcustomer;
        private System.Windows.Forms.Button buttonCancelAddC;
    }
}