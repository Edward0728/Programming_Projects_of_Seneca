﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data;
using System.Data.OleDb;

namespace FinalProjecrt
{
    public partial class frmSearchEvent : Form
    {
        DataTable vt = new DataTable();
        public static int searchID;
        public static decimal searchPrice;
        public static string searchDes;
        public static int searchAvailable;
        public static int searchSoldN;

        // DataGridView dataGridView1 = new DataGridView();
        public frmSearchEvent()
        {
            InitializeComponent();
        }

        private void ButtonSearch_Click(object sender, EventArgs e)
        {
            
            string sqlSearch = "SELECT * FROM EventRecords WHERE EventID =" + numericSearchID.Value;
            String constr = " Provider=Microsoft.ACE.OLEDB.12.0;Data Source= DatabaseProject.accdb"; ;
            OleDbDataAdapter da = new OleDbDataAdapter(sqlSearch, constr);
            //constr tells the program what program we are using (in this case microsoft access)
            //OleDbConnection conobj = new OleDbConnection(constr);
            //conobj.Open();
            //da.InsertCommand = new OleDbCommand(sqlSearch, conobj);
            //da.InsertCommand.ExecuteNonQuery();
            //executes the SQL code
            //conobj.Close();
            if (da != null)
            {
                da.Fill(vt);
                //da.Fill(vt);
                da.Dispose();
                dataGridView1.DataSource = vt;
            }
        }

        private void DataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            // if (dataGridView1.SelectedCells.Count > 0)
            //{
            //  string id = gridview.SelectedCells[0].Value.ToString();
            //}

            if (vt != null)
            {
                bool catched = false;
                // int searchID;
                try
                {
                    searchID = (int)dataGridView1[0, e.RowIndex].Value;
                    searchPrice = (decimal)dataGridView1[4, e.RowIndex].Value;
                    searchDes = (string)dataGridView1[1, e.RowIndex].Value;
                    searchAvailable = (int)dataGridView1[5, e.RowIndex].Value;
                    searchSoldN = (int)dataGridView1[6, e.RowIndex].Value;
                }
                catch(ArgumentOutOfRangeException exception)
                {
                    catched = true;

                }
                catch(InvalidCastException exception)
                {
                    catched = true;
                }
                if (catched == false)
                {
                    this.Hide();
                    frmPurchase frm2 = new frmPurchase(searchID, searchPrice);
                    frm2.ShowDialog();
                    this.Hide();
                }

            }
        }

        private void FrmSearchEvent_Load(object sender, EventArgs e)
        {

        }

        private void ButtonExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
    }

