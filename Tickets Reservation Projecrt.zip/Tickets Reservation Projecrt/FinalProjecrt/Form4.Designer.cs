﻿namespace FinalProjecrt
{
    partial class frmReceipt
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelTitleR = new System.Windows.Forms.Label();
            this.labelAdress = new System.Windows.Forms.Label();
            this.labelContactN = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.buttonPrint = new System.Windows.Forms.Button();
            this.labelDescr = new System.Windows.Forms.Label();
            this.labelItemN = new System.Windows.Forms.Label();
            this.labelPrice = new System.Windows.Forms.Label();
            this.labeldescrip = new System.Windows.Forms.Label();
            this.labelitemnumber = new System.Windows.Forms.Label();
            this.labeltotalpric = new System.Windows.Forms.Label();
            this.labelSeatN = new System.Windows.Forms.Label();
            this.labelseatnumber = new System.Windows.Forms.Label();
            this.labelAfterN = new System.Windows.Forms.Label();
            this.labelafteravailablen = new System.Windows.Forms.Label();
            this.labelAfterSold = new System.Windows.Forms.Label();
            this.labelaftersoldn = new System.Windows.Forms.Label();
            this.labelReceiptID = new System.Windows.Forms.Label();
            this.labelreceiptn = new System.Windows.Forms.Label();
            this.labelreceiptCard = new System.Windows.Forms.Label();
            this.labelApproved = new System.Windows.Forms.Label();
            this.labelReceiptQua = new System.Windows.Forms.Label();
            this.labelreceiptquantity = new System.Windows.Forms.Label();
            this.labelTime = new System.Windows.Forms.Label();
            this.labeltimerecord = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // labelTitleR
            // 
            this.labelTitleR.AutoSize = true;
            this.labelTitleR.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTitleR.Location = new System.Drawing.Point(370, 79);
            this.labelTitleR.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.labelTitleR.Name = "labelTitleR";
            this.labelTitleR.Size = new System.Drawing.Size(122, 39);
            this.labelTitleR.TabIndex = 0;
            this.labelTitleR.Text = "Receipt";
            // 
            // labelAdress
            // 
            this.labelAdress.AutoSize = true;
            this.labelAdress.Location = new System.Drawing.Point(224, 115);
            this.labelAdress.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.labelAdress.Name = "labelAdress";
            this.labelAdress.Size = new System.Drawing.Size(431, 25);
            this.labelAdress.TabIndex = 1;
            this.labelAdress.Text = "1750 Finch Ave E, North York, ON M2J 2X5";
            // 
            // labelContactN
            // 
            this.labelContactN.AutoSize = true;
            this.labelContactN.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelContactN.Location = new System.Drawing.Point(344, 140);
            this.labelContactN.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.labelContactN.Name = "labelContactN";
            this.labelContactN.Size = new System.Drawing.Size(173, 26);
            this.labelContactN.TabIndex = 2;
            this.labelContactN.Text = "(416) 491-5050";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(734, 79);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 82;
            this.dataGridView1.Size = new System.Drawing.Size(815, 473);
            this.dataGridView1.TabIndex = 3;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DataGridView1_CellClick);
            // 
            // buttonPrint
            // 
            this.buttonPrint.Location = new System.Drawing.Point(320, 602);
            this.buttonPrint.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.buttonPrint.Name = "buttonPrint";
            this.buttonPrint.Size = new System.Drawing.Size(150, 44);
            this.buttonPrint.TabIndex = 4;
            this.buttonPrint.Text = "Print";
            this.buttonPrint.UseVisualStyleBackColor = true;
            this.buttonPrint.Click += new System.EventHandler(this.ButtonPrint_Click);
            // 
            // labelDescr
            // 
            this.labelDescr.AutoSize = true;
            this.labelDescr.Location = new System.Drawing.Point(152, 196);
            this.labelDescr.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.labelDescr.Name = "labelDescr";
            this.labelDescr.Size = new System.Drawing.Size(120, 25);
            this.labelDescr.TabIndex = 5;
            this.labelDescr.Text = "Description";
            // 
            // labelItemN
            // 
            this.labelItemN.AutoSize = true;
            this.labelItemN.Location = new System.Drawing.Point(314, 196);
            this.labelItemN.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.labelItemN.Name = "labelItemN";
            this.labelItemN.Size = new System.Drawing.Size(127, 25);
            this.labelItemN.TabIndex = 6;
            this.labelItemN.Text = "ItemNumber";
            // 
            // labelPrice
            // 
            this.labelPrice.AutoSize = true;
            this.labelPrice.Location = new System.Drawing.Point(510, 288);
            this.labelPrice.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.labelPrice.Name = "labelPrice";
            this.labelPrice.Size = new System.Drawing.Size(66, 25);
            this.labelPrice.TabIndex = 7;
            this.labelPrice.Text = "Total:";
            // 
            // labeldescrip
            // 
            this.labeldescrip.AutoSize = true;
            this.labeldescrip.Location = new System.Drawing.Point(152, 242);
            this.labeldescrip.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.labeldescrip.Name = "labeldescrip";
            this.labeldescrip.Size = new System.Drawing.Size(60, 25);
            this.labeldescrip.TabIndex = 8;
            this.labeldescrip.Text = "????";
            // 
            // labelitemnumber
            // 
            this.labelitemnumber.AutoSize = true;
            this.labelitemnumber.Location = new System.Drawing.Point(314, 242);
            this.labelitemnumber.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.labelitemnumber.Name = "labelitemnumber";
            this.labelitemnumber.Size = new System.Drawing.Size(60, 25);
            this.labelitemnumber.TabIndex = 9;
            this.labelitemnumber.Text = "####";
            // 
            // labeltotalpric
            // 
            this.labeltotalpric.AutoSize = true;
            this.labeltotalpric.Location = new System.Drawing.Point(614, 288);
            this.labeltotalpric.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.labeltotalpric.Name = "labeltotalpric";
            this.labeltotalpric.Size = new System.Drawing.Size(60, 25);
            this.labeltotalpric.TabIndex = 10;
            this.labeltotalpric.Text = "$$$$";
            // 
            // labelSeatN
            // 
            this.labelSeatN.AutoSize = true;
            this.labelSeatN.Location = new System.Drawing.Point(558, 196);
            this.labelSeatN.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.labelSeatN.Name = "labelSeatN";
            this.labelSeatN.Size = new System.Drawing.Size(137, 25);
            this.labelSeatN.TabIndex = 11;
            this.labelSeatN.Text = "Seat Number";
            // 
            // labelseatnumber
            // 
            this.labelseatnumber.AutoSize = true;
            this.labelseatnumber.Location = new System.Drawing.Point(558, 242);
            this.labelseatnumber.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.labelseatnumber.Name = "labelseatnumber";
            this.labelseatnumber.Size = new System.Drawing.Size(60, 25);
            this.labelseatnumber.TabIndex = 12;
            this.labelseatnumber.Text = "####";
            // 
            // labelAfterN
            // 
            this.labelAfterN.AutoSize = true;
            this.labelAfterN.Location = new System.Drawing.Point(134, 685);
            this.labelAfterN.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.labelAfterN.Name = "labelAfterN";
            this.labelAfterN.Size = new System.Drawing.Size(170, 25);
            this.labelAfterN.TabIndex = 13;
            this.labelAfterN.Text = "* Seat Available:";
            // 
            // labelafteravailablen
            // 
            this.labelafteravailablen.AutoSize = true;
            this.labelafteravailablen.Location = new System.Drawing.Point(314, 685);
            this.labelafteravailablen.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.labelafteravailablen.Name = "labelafteravailablen";
            this.labelafteravailablen.Size = new System.Drawing.Size(36, 25);
            this.labelafteravailablen.TabIndex = 14;
            this.labelafteravailablen.Text = "##";
            this.labelafteravailablen.Click += new System.EventHandler(this.Labelafternumber_Click);
            // 
            // labelAfterSold
            // 
            this.labelAfterSold.AutoSize = true;
            this.labelAfterSold.Location = new System.Drawing.Point(418, 685);
            this.labelAfterSold.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.labelAfterSold.Name = "labelAfterSold";
            this.labelAfterSold.Size = new System.Drawing.Size(111, 25);
            this.labelAfterSold.TabIndex = 15;
            this.labelAfterSold.Text = "Seat Sold:";
            // 
            // labelaftersoldn
            // 
            this.labelaftersoldn.AutoSize = true;
            this.labelaftersoldn.Location = new System.Drawing.Point(538, 685);
            this.labelaftersoldn.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.labelaftersoldn.Name = "labelaftersoldn";
            this.labelaftersoldn.Size = new System.Drawing.Size(36, 25);
            this.labelaftersoldn.TabIndex = 16;
            this.labelaftersoldn.Text = "##";
            // 
            // labelReceiptID
            // 
            this.labelReceiptID.AutoSize = true;
            this.labelReceiptID.Location = new System.Drawing.Point(146, 321);
            this.labelReceiptID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelReceiptID.Name = "labelReceiptID";
            this.labelReceiptID.Size = new System.Drawing.Size(98, 25);
            this.labelReceiptID.TabIndex = 17;
            this.labelReceiptID.Text = "OrderID: ";
            // 
            // labelreceiptn
            // 
            this.labelreceiptn.AutoSize = true;
            this.labelreceiptn.Location = new System.Drawing.Point(234, 321);
            this.labelreceiptn.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelreceiptn.Name = "labelreceiptn";
            this.labelreceiptn.Size = new System.Drawing.Size(60, 25);
            this.labelreceiptn.TabIndex = 18;
            this.labelreceiptn.Text = "####";
            // 
            // labelreceiptCard
            // 
            this.labelreceiptCard.AutoSize = true;
            this.labelreceiptCard.Location = new System.Drawing.Point(146, 381);
            this.labelreceiptCard.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.labelreceiptCard.Name = "labelreceiptCard";
            this.labelreceiptCard.Size = new System.Drawing.Size(204, 25);
            this.labelreceiptCard.TabIndex = 20;
            this.labelreceiptCard.Text = "################";
            // 
            // labelApproved
            // 
            this.labelApproved.AutoSize = true;
            this.labelApproved.Location = new System.Drawing.Point(248, 469);
            this.labelApproved.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.labelApproved.Name = "labelApproved";
            this.labelApproved.Size = new System.Drawing.Size(270, 25);
            this.labelApproved.TabIndex = 22;
            this.labelApproved.Text = "APPROVED - THANK YOU";
            // 
            // labelReceiptQua
            // 
            this.labelReceiptQua.AutoSize = true;
            this.labelReceiptQua.Location = new System.Drawing.Point(454, 196);
            this.labelReceiptQua.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.labelReceiptQua.Name = "labelReceiptQua";
            this.labelReceiptQua.Size = new System.Drawing.Size(92, 25);
            this.labelReceiptQua.TabIndex = 23;
            this.labelReceiptQua.Text = "Quantity";
            // 
            // labelreceiptquantity
            // 
            this.labelreceiptquantity.AutoSize = true;
            this.labelreceiptquantity.Location = new System.Drawing.Point(448, 242);
            this.labelreceiptquantity.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.labelreceiptquantity.Name = "labelreceiptquantity";
            this.labelreceiptquantity.Size = new System.Drawing.Size(36, 25);
            this.labelreceiptquantity.TabIndex = 24;
            this.labelreceiptquantity.Text = "##";
            // 
            // labelTime
            // 
            this.labelTime.AutoSize = true;
            this.labelTime.Location = new System.Drawing.Point(146, 413);
            this.labelTime.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.labelTime.Name = "labelTime";
            this.labelTime.Size = new System.Drawing.Size(146, 25);
            this.labelTime.TabIndex = 26;
            this.labelTime.Text = "Time Record: ";
            // 
            // labeltimerecord
            // 
            this.labeltimerecord.AutoSize = true;
            this.labeltimerecord.Location = new System.Drawing.Point(314, 413);
            this.labeltimerecord.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.labeltimerecord.Name = "labeltimerecord";
            this.labeltimerecord.Size = new System.Drawing.Size(254, 25);
            this.labeltimerecord.TabIndex = 27;
            this.labeltimerecord.Text = "yyyy, mm, dd, hh, mm, ss";
            // 
            // frmReceipt
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1600, 865);
            this.Controls.Add(this.labeltimerecord);
            this.Controls.Add(this.labelTime);
            this.Controls.Add(this.labelreceiptquantity);
            this.Controls.Add(this.labelReceiptQua);
            this.Controls.Add(this.labelApproved);
            this.Controls.Add(this.labelreceiptCard);
            this.Controls.Add(this.labelreceiptn);
            this.Controls.Add(this.labelReceiptID);
            this.Controls.Add(this.labelaftersoldn);
            this.Controls.Add(this.labelAfterSold);
            this.Controls.Add(this.labelafteravailablen);
            this.Controls.Add(this.labelAfterN);
            this.Controls.Add(this.labelseatnumber);
            this.Controls.Add(this.labelSeatN);
            this.Controls.Add(this.labeltotalpric);
            this.Controls.Add(this.labelitemnumber);
            this.Controls.Add(this.labeldescrip);
            this.Controls.Add(this.labelPrice);
            this.Controls.Add(this.labelItemN);
            this.Controls.Add(this.labelDescr);
            this.Controls.Add(this.buttonPrint);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.labelContactN);
            this.Controls.Add(this.labelAdress);
            this.Controls.Add(this.labelTitleR);
            this.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.Name = "frmReceipt";
            this.Text = "Receipt";
            this.Load += new System.EventHandler(this.FrmReceipt_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelTitleR;
        private System.Windows.Forms.Label labelAdress;
        private System.Windows.Forms.Label labelContactN;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button buttonPrint;
        private System.Windows.Forms.Label labelDescr;
        private System.Windows.Forms.Label labelItemN;
        private System.Windows.Forms.Label labelPrice;
        private System.Windows.Forms.Label labeldescrip;
        private System.Windows.Forms.Label labelitemnumber;
        private System.Windows.Forms.Label labeltotalpric;
        public  System.Windows.Forms.Label labelSeatN;
        private System.Windows.Forms.Label labelseatnumber;
        private System.Windows.Forms.Label labelAfterN;
        private System.Windows.Forms.Label labelafteravailablen;
        private System.Windows.Forms.Label labelAfterSold;
        private System.Windows.Forms.Label labelaftersoldn;
        private System.Windows.Forms.Label labelReceiptID;
        private System.Windows.Forms.Label labelreceiptn;
        private System.Windows.Forms.Label labelreceiptCard;
        private System.Windows.Forms.Label labelApproved;
        private System.Windows.Forms.Label labelReceiptQua;
        private System.Windows.Forms.Label labelreceiptquantity;
        private System.Windows.Forms.Label labelTime;
        private System.Windows.Forms.Label labeltimerecord;
    }
}