﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data;
using System.Data.OleDb;

namespace FinalProjecrt
{
    public partial class frmReceipt : Form
    {
        DataTable vt = new DataTable();
     
        public frmReceipt()
        {
            InitializeComponent();
            labelafteravailablen.Text = Convert.ToString(frmSearchEvent.searchAvailable - frmPurchase.ticketN);
            labelaftersoldn.Text = Convert.ToString(frmSearchEvent.searchSoldN + frmPurchase.ticketN);
            labeltotalpric.Text = Convert.ToString(frmPurchase.totalP);
        }

      

        private void FrmReceipt_Load(object sender, EventArgs e)
        {
            OleDbDataAdapter da = new OleDbDataAdapter();

            //string sqlAddR = "INSERT INTO OrderRecords (CustomerID,EventID,SeatNumber) " +
            //   "VALUES ('" + Convert.ToInt32(frmPurchase.textIDpurchase.Text) + "', '"+Convert.ToInt32(frmSearchEvent.numericSearchID.Value)+"','" + Convert.ToInt32(frmPurchase.textSeatN.Text) + "')";   
            string sqlAddR = "INSERT INTO OrderRecords (CustomerID,EventID,SeatNumber) " +
               "VALUES (" + Convert.ToInt32(frmPurchase.customerID) + ", "+Convert.ToInt32(frmPurchase.eventID) +",'" + Convert.ToString(frmPurchase.seatN) + "')"; 

            String constr = " Provider=Microsoft.ACE.OLEDB.12.0;Data Source= DatabaseProject.accdb";
            //Provider = Microsoft.ACE.OLEDB.12.0; Data Source = DatabaseProject.accdb
            OleDbConnection conobj = new OleDbConnection(constr);
            conobj.Open();
            da.InsertCommand = new OleDbCommand(sqlAddR, conobj);
            da.InsertCommand.ExecuteNonQuery();
            conobj.Close();

            string sqlShowR = "SELECT * FROM OrderRecords WHERE CustomerID = " + Convert.ToInt32(frmPurchase.customerID);      
            OleDbDataAdapter daR = new OleDbDataAdapter(sqlShowR, constr);       
            if (daR != null)
            {
                daR.Fill(vt);
                //da.Fill(vt);
                daR.Dispose();
                dataGridView1.DataSource = vt;
            }
           
        }

        private void DataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            bool catched = false;
            try
            {
                labelreceiptn.Text = Convert.ToString(dataGridView1[0, e.RowIndex].Value);
                labeldescrip.Text = frmSearchEvent.searchDes;
                labelitemnumber.Text = Convert.ToString(dataGridView1[2, e.RowIndex].Value);
                labeltotalpric.Text = Convert.ToString(frmPurchase.totalP);
                labelseatnumber.Text = Convert.ToString(dataGridView1[3, e.RowIndex].Value);
                labelreceiptCard.Text = frmPurchase.cardN;
                labelreceiptquantity.Text = Convert.ToString(frmPurchase.ticketN);
            }
            catch (ArgumentOutOfRangeException exception)
            {
                catched = true;
            }
            if(catched==false)
            { 
            var time = DateTime.Now;
            string formattedTime = time.ToString();
            labeltimerecord.Text = formattedTime;
            }
        }
        private void ButtonPrint_Click(object sender, EventArgs e)
        {
            OleDbDataAdapter da = new OleDbDataAdapter();

            //string sqlAddR = "INSERT INTO OrderRecords (CustomerID,EventID,SeatNumber) " +
            //   "VALUES ('" + Convert.ToInt32(frmPurchase.textIDpurchase.Text) + "', '"+Convert.ToInt32(frmSearchEvent.numericSearchID.Value)+"','" + Convert.ToInt32(frmPurchase.textSeatN.Text) + "')";   
            string sqlUpdateS = "UPDATE Eventrecords SET NumberofSeatsAvailable = "+Convert.ToInt32(labelafteravailablen.Text)+", NumberofSeatsSold = "+Convert.ToInt32(labelaftersoldn.Text)+"" +
                " WHERE EventID = "+Convert.ToInt32(frmPurchase.eventID)+" ";

            String constr = " Provider=Microsoft.ACE.OLEDB.12.0;Data Source= DatabaseProject.accdb";
            //Provider = Microsoft.ACE.OLEDB.12.0; Data Source = DatabaseProject.accdb
            OleDbConnection conobj = new OleDbConnection(constr);
            conobj.Open();
            da.UpdateCommand = new OleDbCommand(sqlUpdateS, conobj);
            da.UpdateCommand.ExecuteNonQuery();
            conobj.Close();
            frmSearchEvent frm0 = new frmSearchEvent();
            frm0.Show();

            var time = DateTime.Now;
            string formattedTime = time.ToString();
            labeltimerecord.Text = formattedTime;

            this.Hide();
        }

        private void Labelafternumber_Click(object sender, EventArgs e)
        {

        }
    }
}
